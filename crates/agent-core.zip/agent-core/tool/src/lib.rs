//! Tool abstractions for ascnet-lucia.
//!
//! 工具抽象层：这里不关心 OpenAI / Anthropic，也不关心 WASM 运行时。
//! Tool layer: this crate does not know about OpenAI / Anthropic or the WASM runtime.

#![deny(missing_docs)]

use anyhow::{anyhow, Result};
use async_trait::async_trait;
use serde::{de::DeserializeOwned, Deserialize, Serialize};
use serde_json::{json, Value};
use std::{collections::HashMap, future::Future, pin::Pin, sync::Arc};

/// JSON Schema for a tool input.
/// 工具输入参数的 JSON Schema。
pub type JsonSchema = Value;

/// 工具调用触达的宿主权限范围，由注册工具的可信定义声明并由 Core 绑定到实际调用。
///
/// `write` 同时覆盖创建、修改与删除；旧插件未声明该字段时使用 `unknown`，权限策略应
/// 保守审批。该元数据只用于宿主策略，不会发送给模型服务商。
#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize, PartialEq, Eq, Hash)]
#[serde(rename_all = "snake_case")]
pub enum ToolPermissionScope {
    /// 插件未声明或 Host 无法解析权限范围，必须按未知副作用处理。
    #[default]
    Unknown,
    /// 只操作 Lucia 内部状态或已编入可信目录的元数据，不扩大调用方的宿主资源访问。
    Control,
    /// 读取宿主文件、目录或其他受保护数据。
    Read,
    /// 创建、修改或删除宿主文件与其他持久数据。
    Write,
    /// 执行 Shell 或其他宿主原生进程。
    Shell,
    /// 访问外部网络或远端服务。
    Network,
}

impl ToolPermissionScope {
    /// 返回当前 scope 是否缺少可信声明，供 serde 保持旧 JSON 形状。
    fn is_unknown(&self) -> bool {
        matches!(self, Self::Unknown)
    }

    /// 返回 manifest、审计和授权界面共用的稳定协议名称。
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Unknown => "unknown",
            Self::Control => "control",
            Self::Read => "read",
            Self::Write => "write",
            Self::Shell => "shell",
            Self::Network => "network",
        }
    }
}

/// A tool definition visible to the model.
/// 暴露给模型看的工具定义。
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ToolSpec {
    /// Stable tool name. Use snake_case; model providers are usually strict about names.
    /// 稳定工具名。建议使用 snake_case；模型服务商通常对名称较严格。
    pub name: String,

    /// Human-readable description used by the model for tool selection.
    /// 给模型看的描述，用于帮助模型选择是否调用该工具。
    pub description: String,

    /// JSON Schema object that describes the expected input arguments.
    /// 描述工具输入参数的 JSON Schema 对象。
    pub input_schema: JsonSchema,

    /// 工具触达的权限范围；旧定义缺失时按未知副作用处理。
    #[serde(default, skip_serializing_if = "ToolPermissionScope::is_unknown")]
    pub permission_scope: ToolPermissionScope,
}

impl ToolSpec {
    /// Build a new tool spec.
    /// 创建一个新的工具定义。
    pub fn new(
        name: impl Into<String>,
        description: impl Into<String>,
        input_schema: JsonSchema,
    ) -> Self {
        Self {
            name: name.into(),
            description: description.into(),
            input_schema,
            permission_scope: ToolPermissionScope::Unknown,
        }
    }

    /// 为工具声明权限范围；该声明由 Core/Host 绑定到实际调用，模型参数不能覆盖。
    pub fn with_permission_scope(mut self, permission_scope: ToolPermissionScope) -> Self {
        self.permission_scope = permission_scope;
        self
    }

    /// A schema for tools that do not require arguments.
    /// 无参数工具可使用的空对象 schema。
    pub fn empty_object_schema() -> JsonSchema {
        json!({
            "type": "object",
            "properties": {},
            "additionalProperties": false
        })
    }

    /// Validate the subset of naming rules accepted by common providers.
    /// 校验常见模型服务商都能接受的工具命名子集。
    pub fn validate_name(&self) -> Result<()> {
        validate_tool_name(&self.name)
    }
}

/// A tool call requested by the model.
/// 模型请求执行的一次工具调用。
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ToolCall {
    /// Provider-neutral call id. It must be returned with the tool result.
    /// 与服务商无关的调用 ID，工具结果必须带回这个 ID。
    pub id: String,

    /// Tool name.
    /// 工具名称。
    pub name: String,

    /// Parsed JSON arguments.
    /// 已解析的 JSON 参数。
    pub args: Value,

    /// Core/Host 从已注册工具定义绑定的可信权限范围；模型响应中的同名字段不得直接使用。
    #[serde(default, skip_serializing_if = "ToolPermissionScope::is_unknown")]
    pub permission_scope: ToolPermissionScope,

    /// Core 为当前 Agent 运行绑定的可信 ID，供有状态策略隔离并发审批。
    ///
    /// Provider、历史消息或 Guest 自报值均不可信；Core 会在每次进入扩展链前覆盖该字段。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub run_id: Option<String>,

    /// 应用为当前 Agent 绑定的稳定会话 ID，供有状态工具隔离不同会话的数据。
    ///
    /// 模型响应或历史消息中的值不可信；Core 会在工具准入前使用当前 Agent 的会话路由键
    /// 覆盖该字段。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub session_id: Option<String>,
}

impl ToolCall {
    /// Construct a tool call.
    /// 构造一次工具调用。
    pub fn new(id: impl Into<String>, name: impl Into<String>, args: Value) -> Self {
        Self {
            id: id.into(),
            name: name.into(),
            args,
            permission_scope: ToolPermissionScope::Unknown,
            run_id: None,
            session_id: None,
        }
    }

    /// 覆盖为宿主已验证的工具权限范围；仅注册表或 Host 路由层应调用。
    pub fn bind_permission_scope(&mut self, permission_scope: ToolPermissionScope) {
        self.permission_scope = permission_scope;
    }

    /// 覆盖为 Core 当前运行的可信 ID；仅 Agent 运行循环或 Host 重写路由应调用。
    pub fn bind_run_id(&mut self, run_id: impl Into<String>) {
        self.run_id = Some(run_id.into());
    }

    /// Deserialize arguments into a typed Rust value.
    /// 将工具参数反序列化为强类型 Rust 值。
    pub fn args_as<T: DeserializeOwned>(&self) -> Result<T> {
        serde_json::from_value(self.args.clone())
            .map_err(|err| anyhow!("invalid arguments for tool `{}`: {err}", self.name))
    }

    /// Serialize arguments back to JSON text for provider protocols.
    /// 将工具参数重新序列化为 JSON 文本，供模型协议适配层使用。
    pub fn args_json_string(&self) -> String {
        serde_json::to_string(&self.args).unwrap_or_else(|_| "{}".to_string())
    }
}

/// Result returned by a tool.
/// 工具执行返回的结果。
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ToolResult {
    /// The id of the tool call this result belongs to.
    /// 该结果对应的工具调用 ID。
    pub call_id: String,

    /// Tool name. This is redundant but useful for logs and plugin routing.
    /// 工具名。虽然和 call_id 有冗余，但对日志和插件路由很有用。
    pub name: String,

    /// JSON payload returned to the model.
    /// 返回给模型的 JSON 载荷。
    pub content: Value,

    /// Whether the tool failed. The ReAct loop still returns the error to the model.
    /// 工具是否失败。即使失败，ReAct loop 也会把错误结果回传给模型。
    pub is_error: bool,

    /// 由可信执行层给出的稳定错误类别；成功或旧版结果没有该字段时为 `None`。
    ///
    /// Guest 可以序列化该字段，但 Host 必须按实际来源决定是否信任，不能直接据此形成
    /// 权限或安全结论。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error_kind: Option<ToolErrorKind>,

    /// UI 专用的结构化细节（diff 预览、执行耗时等），不会发送给模型。
    /// content 与 details 分离：模型只看 content，UI 只看 details。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub details: Option<Value>,
}

/// 工具失败的稳定机器可读类别。
///
/// 该枚举只描述执行层事实，不表示最终任务 Outcome；安全类别必须由 Host 或原生工具
/// 注入，普通 Guest 自报不能获得可信性。
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ToolErrorKind {
    /// 工具名称未注册。
    UnknownTool,
    /// 工具参数无法解析或未通过契约校验。
    InvalidArguments,
    /// 工具已执行但返回普通失败。
    Execution,
    /// 执行策略未授予所需权限。
    PermissionDenied,
    /// 文件路径越过工作区边界。
    PathBoundaryViolation,
    /// 进程调用越过执行策略边界。
    ProcessBoundaryViolation,
    /// 操作尝试读取或传递 Secret。
    SecretAccessAttempt,
    /// Runtime 工具 allowlist 拒绝调用。
    PolicyDenied,
    /// 运行取消导致工具未执行。
    Cancelled,
}

/// 工具运行期间产生的输出流类别。
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ToolOutputStream {
    /// 标准输出。
    Stdout,
    /// 标准错误。
    Stderr,
}

/// 工具运行期间产生的一段增量输出。
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ToolOutputDelta {
    /// 输出所属工具调用的稳定 ID。
    pub call_id: String,
    /// 输出来源，供界面区分 stdout 与 stderr。
    pub stream: ToolOutputStream,
    /// 本次新增的文本；调用方应按接收顺序拼接。
    pub delta: String,
}

/// 接收工具运行期增量输出的同步接口。
///
/// 实现必须快速返回；需要异步持久化或渲染时应转发到内部队列。
pub trait ToolOutputSink: Send + Sync {
    /// 接收一段工具输出。接收失败不应中断工具本身。
    fn emit(&self, output: ToolOutputDelta);
}

/// 丢弃全部工具运行期输出的默认接收器。
#[derive(Debug, Clone, Default)]
pub struct NoopToolOutputSink;

impl ToolOutputSink for NoopToolOutputSink {
    fn emit(&self, _output: ToolOutputDelta) {}
}

impl ToolResult {
    /// Construct a successful tool result.
    /// 构造成功的工具结果。
    pub fn success(call_id: impl Into<String>, name: impl Into<String>, content: Value) -> Self {
        Self {
            call_id: call_id.into(),
            name: name.into(),
            content,
            is_error: false,
            error_kind: None,
            details: None,
        }
    }

    /// Construct an error tool result.
    /// 构造失败的工具结果。
    pub fn error(
        call_id: impl Into<String>,
        name: impl Into<String>,
        message: impl Into<String>,
    ) -> Self {
        Self {
            call_id: call_id.into(),
            name: name.into(),
            content: json!({ "error": message.into() }),
            is_error: true,
            error_kind: Some(ToolErrorKind::Execution),
            details: None,
        }
    }

    /// 构造带稳定类别的失败结果。
    ///
    /// `kind` 只应由知道真实执行边界的 Core、Host 或原生工具提供；调用方仍需按结果
    /// 来源决定是否把安全类别提升为可信 Incident。
    pub fn error_with_kind(
        call_id: impl Into<String>,
        name: impl Into<String>,
        kind: ToolErrorKind,
        message: impl Into<String>,
    ) -> Self {
        Self {
            call_id: call_id.into(),
            name: name.into(),
            content: json!({ "error": message.into() }),
            is_error: true,
            error_kind: Some(kind),
            details: None,
        }
    }

    /// 以 builder 风格附加 UI 细节。
    pub fn with_details(mut self, details: Value) -> Self {
        self.details = Some(details);
        self
    }

    /// Convert the result payload to provider-friendly text.
    /// 将工具结果转为模型服务商协议更容易接受的文本。
    pub fn content_text(&self) -> String {
        if let Some(text) = self.content.as_str() {
            text.to_string()
        } else {
            serde_json::to_string(&self.content).unwrap_or_else(|_| "null".to_string())
        }
    }
}

/// Trait implemented by host-native tools.
/// 宿主进程内原生工具需要实现的 trait。
#[async_trait]
pub trait Tool: Send + Sync {
    /// Return the tool definition sent to the model.
    /// 返回发送给模型的工具定义。
    fn spec(&self) -> ToolSpec;

    /// Execute the tool call.
    /// 执行工具调用。
    async fn call(&self, call: ToolCall) -> Result<ToolResult>;

    /// 执行工具调用，并把可用的运行期输出发送给接收器。
    ///
    /// 默认实现兼容不支持增量输出的工具，只调用 [`Tool::call`]。实现增量输出的工具
    /// 应覆盖此方法，但最终 [`ToolResult`] 必须与普通调用保持一致。
    async fn call_with_output(
        &self,
        call: ToolCall,
        _output: Arc<dyn ToolOutputSink>,
    ) -> Result<ToolResult> {
        self.call(call).await
    }
}

/// Async function type used by [`JsonTool`].
/// [`JsonTool`] 使用的异步函数类型。
pub type BoxedToolFuture = Pin<Box<dyn Future<Output = Result<Value>> + Send>>;

/// A convenient tool wrapper around an async JSON function.
/// 一个便捷工具包装器：把异步 JSON 函数包装成 Tool。
pub struct JsonTool {
    spec: ToolSpec,
    handler: Arc<dyn Fn(Value) -> BoxedToolFuture + Send + Sync>,
}

impl JsonTool {
    /// Create a tool from a spec and an async handler.
    /// 用工具定义和异步处理函数创建工具。
    pub fn new<F, Fut>(spec: ToolSpec, handler: F) -> Self
    where
        F: Fn(Value) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<Value>> + Send + 'static,
    {
        Self {
            spec,
            handler: Arc::new(move |args| Box::pin(handler(args))),
        }
    }
}

#[async_trait]
impl Tool for JsonTool {
    fn spec(&self) -> ToolSpec {
        self.spec.clone()
    }

    async fn call(&self, call: ToolCall) -> Result<ToolResult> {
        let content = (self.handler)(call.args.clone()).await?;
        Ok(ToolResult::success(call.id, call.name, content))
    }
}

/// Registry for host-native tools.
/// 宿主进程内原生工具注册表。
#[derive(Default, Clone)]
pub struct ToolRegistry {
    tools: HashMap<String, Arc<dyn Tool>>,
}

impl ToolRegistry {
    /// Create an empty registry.
    /// 创建空注册表。
    pub fn new() -> Self {
        Self::default()
    }

    /// Register a tool.
    /// 注册一个工具。
    ///
    /// # Errors
    ///
    /// 工具名称不符合跨服务商规则，或注册表中已存在同名工具时返回错误。
    pub fn register<T>(&mut self, tool: T) -> Result<&mut Self>
    where
        T: Tool + 'static,
    {
        self.register_arc(Arc::new(tool))
    }

    /// Register an already shared tool.
    /// 注册一个已经被 Arc 包装的工具。
    ///
    /// # Errors
    ///
    /// 工具名称不符合跨服务商规则，或注册表中已存在同名工具时返回错误。
    pub fn register_arc(&mut self, tool: Arc<dyn Tool>) -> Result<&mut Self> {
        let spec = tool.spec();
        spec.validate_name()?;
        if self.tools.contains_key(&spec.name) {
            return Err(anyhow!("duplicated tool: {}", spec.name));
        }
        self.tools.insert(spec.name, tool);
        Ok(self)
    }

    /// Check if the registry contains a tool.
    /// 检查注册表是否包含某个工具。
    pub fn contains(&self, name: &str) -> bool {
        self.tools.contains_key(name)
    }

    /// 按名称获取共享工具实例。
    ///
    /// 返回的实例与当前注册表共享所有权，可用于构造权限收缩后的独立注册表。
    pub fn get(&self, name: &str) -> Option<Arc<dyn Tool>> {
        self.tools.get(name).cloned()
    }

    /// 按名称构造当前注册表的子集。
    ///
    /// 子集复用原工具实例，但拥有独立的名称映射。
    ///
    /// # Errors
    ///
    /// 任一名称不存在，或输入包含重复名称时返回错误。
    pub fn subset<I, S>(&self, names: I) -> Result<Self>
    where
        I: IntoIterator<Item = S>,
        S: AsRef<str>,
    {
        let mut subset = Self::new();
        for name in names {
            let name = name.as_ref();
            let tool = self
                .get(name)
                .ok_or_else(|| anyhow!("unknown tool: {name}"))?;
            subset.register_arc(tool)?;
        }
        Ok(subset)
    }

    /// Return all tool specs sorted by name.
    /// 按名称稳定排序并返回所有工具定义。
    ///
    /// 稳定顺序用于保证模型请求、提示缓存键和测试快照可复现，不反映注册顺序。
    pub fn specs(&self) -> Vec<ToolSpec> {
        let mut specs = self
            .tools
            .values()
            .map(|tool| tool.spec())
            .collect::<Vec<_>>();
        specs.sort_by(|left, right| left.name.cmp(&right.name));
        specs
    }

    /// Execute a tool call.
    /// 执行一次工具调用。
    ///
    /// # Errors
    ///
    /// 调用引用未知工具，或工具实现执行失败时返回错误。
    pub async fn call(&self, call: ToolCall) -> Result<ToolResult> {
        let Some(tool) = self.tools.get(&call.name) else {
            return Err(anyhow!("unknown tool: {}", call.name));
        };
        tool.call(call).await
    }

    /// 执行一次工具调用，并转发工具实现提供的运行期输出。
    ///
    /// # Errors
    ///
    /// 调用引用未知工具，或工具实现执行失败时返回错误。
    pub async fn call_with_output(
        &self,
        call: ToolCall,
        output: Arc<dyn ToolOutputSink>,
    ) -> Result<ToolResult> {
        let Some(tool) = self.tools.get(&call.name) else {
            return Err(anyhow!("unknown tool: {}", call.name));
        };
        tool.call_with_output(call, output).await
    }

    /// Number of registered tools.
    /// 已注册工具数量。
    pub fn len(&self) -> usize {
        self.tools.len()
    }

    /// Whether no tools are registered.
    /// 是否没有注册任何工具。
    pub fn is_empty(&self) -> bool {
        self.tools.is_empty()
    }
}

#[cfg(feature = "builtins")]
pub mod builtins;

pub mod policy;
pub mod workspace;

pub use policy::{ExecutionPolicy, ExecutionProfile, FilesystemScope, ResourceLimits, ToolAccess};
pub use workspace::{
    is_sensitive_path, FileCapabilities, FileCapability, ReadPathGrants, WorkspaceError,
    WorkspaceGuard,
};

/// Validate a provider-portable tool name.
/// 校验跨服务商可移植的工具名称。
///
/// # Errors
///
/// 名称为空、超过 64 个字符，或包含 ASCII 字母、数字、下划线和连字符之外的字符时
/// 返回错误。
pub fn validate_tool_name(name: &str) -> Result<()> {
    if name.is_empty() {
        return Err(anyhow!("tool name cannot be empty"));
    }
    if name.len() > 64 {
        return Err(anyhow!("tool name cannot be longer than 64 characters"));
    }
    let ok = name
        .chars()
        .all(|ch| ch.is_ascii_alphanumeric() || ch == '_' || ch == '-');
    if !ok {
        return Err(anyhow!(
            "tool name `{name}` may only contain ASCII letters, digits, `_`, or `-`"
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    /// 构造只用于注册表顺序测试的 JSON 工具。
    fn test_tool(name: &str) -> JsonTool {
        JsonTool::new(
            ToolSpec::new(name, "测试工具", ToolSpec::empty_object_schema()),
            |_| async { Ok(json!({ "ok": true })) },
        )
    }

    /// 工具定义顺序必须独立于 HashMap 迭代顺序和注册顺序。
    #[test]
    fn specs_are_sorted_by_name() {
        let mut registry = ToolRegistry::new();
        registry
            .register(test_tool("zeta"))
            .expect("注册 zeta 工具");
        registry
            .register(test_tool("alpha"))
            .expect("注册 alpha 工具");
        registry
            .register(test_tool("middle"))
            .expect("注册 middle 工具");

        let names = registry
            .specs()
            .into_iter()
            .map(|spec| spec.name)
            .collect::<Vec<_>>();

        assert_eq!(names, vec!["alpha", "middle", "zeta"]);
    }

    /// 旧 ToolSpec JSON 缺少权限字段时必须解析为 unknown，新字段保持加法兼容。
    #[test]
    fn legacy_tool_spec_defaults_to_unknown_permission_scope() {
        let spec: ToolSpec = serde_json::from_value(json!({
            "name": "legacy",
            "description": "旧工具",
            "input_schema": {"type": "object"}
        }))
        .expect("旧 ToolSpec JSON 应继续解析");

        assert_eq!(spec.permission_scope, ToolPermissionScope::Unknown);
        assert!(serde_json::to_value(spec)
            .expect("序列化旧工具定义")
            .get("permission_scope")
            .is_none());
    }

    /// 旧 ToolCall JSON 缺少 Host 字段时必须兼容，新绑定值才会写入 Guest hook JSON。
    #[test]
    fn tool_call_permission_scope_is_additive_and_host_bound() {
        let mut call: ToolCall = serde_json::from_value(json!({
            "id": "legacy-call",
            "name": "legacy",
            "args": {}
        }))
        .expect("旧 ToolCall JSON 应继续解析");
        assert_eq!(call.permission_scope, ToolPermissionScope::Unknown);
        assert_eq!(call.run_id, None);
        assert_eq!(call.session_id, None);

        call.bind_permission_scope(ToolPermissionScope::Read);
        call.bind_run_id("run-1");
        let encoded = serde_json::to_value(call).expect("序列化已绑定调用");
        assert_eq!(encoded["permission_scope"], "read");
        assert_eq!(encoded["run_id"], "run-1");
    }

    /// 旧插件和历史会话缺少加法错误类别时仍应按普通结果读取。
    #[test]
    fn legacy_tool_result_defaults_missing_error_kind() {
        let result: ToolResult = serde_json::from_value(json!({
            "call_id": "legacy-call",
            "name": "legacy-tool",
            "content": {"error": "旧版错误"},
            "is_error": true
        }))
        .expect("旧版 ToolResult 应保持兼容");

        assert_eq!(result.error_kind, None);
        assert!(result.is_error);
    }
}
