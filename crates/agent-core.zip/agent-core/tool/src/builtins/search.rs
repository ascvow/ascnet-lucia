//! 在文件中搜索文本工具。
//! Search text in files tool.

use crate::{
    FileCapability, Tool, ToolCall, ToolPermissionScope, ToolResult, ToolSpec, WorkspaceGuard,
};
use anyhow::Result;
use async_trait::async_trait;
use serde::Deserialize;
use serde_json::json;
use std::fs;
use std::path::Path;

const DEFAULT_MAX_RESULTS: usize = 50;
const MAX_RESULTS_LIMIT: usize = 500;
const MAX_DEPTH: usize = 12;
/// 跳过大于此字节数的文件。
const MAX_FILE_SIZE: u64 = 1024 * 1024;

/// 跳过的目录名称。
const SKIP_DIRS: &[&str] = &[
    ".git",
    "node_modules",
    "target",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "dist",
    "build",
    ".next",
    ".nuxt",
    ".cache",
];

/// 在目录树中递归搜索文本内容。
/// Recursively search for text content in a directory tree.
///
/// 搜索根目录先经 [`WorkspaceGuard`] 解析，且递归过程不会跟随指向工作区外的符号链接。
pub struct SearchFilesTool {
    /// 默认最大结果数。
    default_max_results: usize,
    /// 工作区守卫，限定可搜索的目录范围。
    guard: WorkspaceGuard,
}

impl Default for SearchFilesTool {
    fn default() -> Self {
        Self {
            default_max_results: DEFAULT_MAX_RESULTS,
            guard: WorkspaceGuard::default(),
        }
    }
}

impl SearchFilesTool {
    /// 使用自定义默认最大结果数创建。
    pub fn with_max_results(max_results: usize) -> Self {
        Self {
            default_max_results: max_results.min(MAX_RESULTS_LIMIT),
            guard: WorkspaceGuard::default(),
        }
    }

    /// 以指定工作区守卫创建工具。
    pub fn new(guard: WorkspaceGuard) -> Self {
        Self {
            default_max_results: DEFAULT_MAX_RESULTS,
            guard,
        }
    }
}

#[derive(Deserialize)]
struct Args {
    pattern: String,
    #[serde(default)]
    path: Option<String>,
    #[serde(default)]
    include: Option<String>,
    #[serde(default)]
    max_results: Option<usize>,
}

#[derive(serde::Serialize)]
struct Match {
    file: String,
    line: usize,
    content: String,
}

/// 检查文件名是否匹配 include 过滤器（如 `*.rs`）。
fn matches_include(file_name: &str, include: &str) -> bool {
    if let Some(suffix) = include.strip_prefix('*') {
        file_name.ends_with(suffix)
    } else {
        file_name == include
    }
}

/// 检查是否为二进制文件（前 512 字节包含 null 字节）。
fn is_likely_binary(buf: &[u8]) -> bool {
    let check_len = buf.len().min(512);
    buf[..check_len].contains(&0)
}

/// 同步递归搜索。
///
/// `boundary` 为工作区根目录。每个条目都以 canonicalize 结果与之比较，因此指向
/// 工作区外的符号链接不会被跟随；`None` 表示不限制目录。
fn search_recursive(
    dir: &Path,
    pattern: &str,
    include: Option<&str>,
    depth: usize,
    results: &mut Vec<Match>,
    max_results: usize,
    boundary: Option<&Path>,
) {
    if depth > MAX_DEPTH || results.len() >= max_results {
        return;
    }

    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };

    let mut dirs = Vec::new();
    let mut files = Vec::new();

    for entry in entries.flatten() {
        let path = entry.path();
        // 逐条目校验真实路径，避免经符号链接读取或遍历工作区之外的内容。
        if let Some(root) = boundary {
            match path.canonicalize() {
                Ok(real) if real.starts_with(root) => {}
                _ => continue,
            }
        }
        if path.is_dir() {
            dirs.push(path);
        } else {
            files.push(path);
        }
    }

    for file_path in files {
        if results.len() >= max_results {
            return;
        }

        let file_name = match file_path.file_name().and_then(|n| n.to_str()) {
            Some(n) => n.to_string(),
            None => continue,
        };

        if let Some(inc) = include {
            if !matches_include(&file_name, inc) {
                continue;
            }
        }

        let meta = match fs::metadata(&file_path) {
            Ok(m) => m,
            Err(_) => continue,
        };

        if meta.len() > MAX_FILE_SIZE {
            continue;
        }

        let bytes = match fs::read(&file_path) {
            Ok(b) => b,
            Err(_) => continue,
        };

        if is_likely_binary(&bytes) {
            continue;
        }

        let content = match std::str::from_utf8(&bytes) {
            Ok(s) => s,
            Err(_) => continue,
        };

        let path_str = file_path.to_string_lossy().to_string();
        for (i, line) in content.lines().enumerate() {
            if line.contains(pattern) {
                results.push(Match {
                    file: path_str.clone(),
                    line: i + 1,
                    content: truncate_line(line, 200),
                });
                if results.len() >= max_results {
                    return;
                }
            }
        }
    }

    for dir_path in dirs {
        if results.len() >= max_results {
            return;
        }
        let dir_name = match dir_path.file_name().and_then(|n| n.to_str()) {
            Some(n) => n,
            None => continue,
        };
        if SKIP_DIRS.contains(&dir_name) {
            continue;
        }
        search_recursive(
            &dir_path,
            pattern,
            include,
            depth + 1,
            results,
            max_results,
            boundary,
        );
    }
}

/// 截断过长的行。
fn truncate_line(line: &str, max_chars: usize) -> String {
    if line.chars().count() <= max_chars {
        line.to_string()
    } else {
        let truncated: String = line.chars().take(max_chars).collect();
        format!("{truncated}...")
    }
}

#[async_trait]
impl Tool for SearchFilesTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec::new(
            "search_files",
            "Recursively search a directory tree for a case-sensitive literal substring and return the matching file, 1-based line number, and line content. Use this to locate files by known text or identifiers. Regular expressions are not supported. Common dependency and build directories, binary or non-UTF-8 files, and files larger than 1 MiB are skipped.",
            json!({
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Case-sensitive literal text to find; matched as a substring, not a regular expression"
                    },
                    "path": {
                        "type": "string",
                        "description": "Root directory for the recursive search; defaults to the current directory"
                    },
                    "include": {
                        "type": "string",
                        "description": "Optional file-name filter; supports only an exact name or a *suffix pattern such as *.rs"
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of matching lines to return; default 50, with truncated=true at the limit",
                        "minimum": 1,
                        "maximum": 500
                    }
                },
                "required": ["pattern"],
                "additionalProperties": false
            }),
        )
        .with_permission_scope(ToolPermissionScope::Read)
    }

    async fn call(&self, call: ToolCall) -> Result<ToolResult> {
        let args: Args = call.args_as()?;
        let max_results = args
            .max_results
            .unwrap_or(self.default_max_results)
            .min(MAX_RESULTS_LIMIT);
        let base_path = args.path.clone().unwrap_or_else(|| ".".to_string());
        let pattern = args.pattern.clone();
        let include = args.include.clone();

        // 搜索起点必须落在工作区内；解析后的规范路径同时作为递归的包含性基准。
        let root = match self
            .guard
            .resolve_existing(&base_path, FileCapability::Read)
        {
            Ok(path) => path,
            Err(error) => {
                return Ok(ToolResult::error_with_kind(
                    call.id,
                    call.name,
                    error.tool_error_kind(),
                    error.to_string(),
                ))
            }
        };
        let boundary = self.guard.root().map(Path::to_path_buf);

        let results = tokio::task::spawn_blocking(move || {
            if !root.is_dir() {
                return Vec::new();
            }
            let mut matches = Vec::new();
            search_recursive(
                &root,
                &pattern,
                include.as_deref(),
                0,
                &mut matches,
                max_results,
                boundary.as_deref(),
            );
            matches
        })
        .await?;

        let count = results.len();
        let truncated = count >= max_results;

        Ok(ToolResult::success(
            call.id,
            call.name,
            json!({
                "matches": results,
                "count": count,
                "truncated": truncated,
            }),
        ))
    }
}
