//! 列出目录内容工具。
//! List directory entries tool.

use crate::{
    FileCapability, Tool, ToolCall, ToolPermissionScope, ToolResult, ToolSpec, WorkspaceGuard,
};
use anyhow::Result;
use async_trait::async_trait;
use serde::Deserialize;
use serde_json::json;

/// 列出目录下的文件和子目录。
/// List files and subdirectories in a directory.
///
/// 目录路径先经 [`WorkspaceGuard`] 解析，工作区之外的目录一律拒绝。
#[derive(Debug, Clone, Default)]
pub struct ListDirectoryTool {
    guard: WorkspaceGuard,
}

impl ListDirectoryTool {
    /// 以指定工作区守卫创建工具。
    pub fn new(guard: WorkspaceGuard) -> Self {
        Self { guard }
    }
}

#[derive(Deserialize)]
struct Args {
    path: String,
}

#[async_trait]
impl Tool for ListDirectoryTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec::new(
            "list_directory",
            "List the direct children of a directory without recursing, returning each entry's name, type, and file size. Directories above 4096 entries are rejected, not truncated. To locate files recursively by content, use search_files instead.",
            json!({
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Directory path to inspect; only direct children are returned"
                    }
                },
                "required": ["path"],
                "additionalProperties": false
            }),
        )
        .with_permission_scope(ToolPermissionScope::Read)
    }

    async fn call(&self, call: ToolCall) -> Result<ToolResult> {
        let args: Args = call.args_as()?;

        let path = match self
            .guard
            .resolve_existing(&args.path, FileCapability::Read)
        {
            Ok(path) => path,
            Err(error) => {
                return Ok(ToolResult::error_with_kind(
                    call.id,
                    call.name,
                    error.tool_error_kind(),
                    error.to_string(),
                ))
            }
        };

        let mut dir = match tokio::fs::read_dir(&path).await {
            Ok(d) => d,
            Err(e) => return Ok(ToolResult::error(call.id, call.name, e.to_string())),
        };

        let mut entries = Vec::new();
        loop {
            let entry = match dir.next_entry().await {
                Ok(Some(entry)) => entry,
                Ok(None) => break,
                Err(error) => return Ok(ToolResult::error(call.id, call.name, error.to_string())),
            };
            if entries.len() >= 4096 {
                return Ok(ToolResult::error(
                    call.id,
                    call.name,
                    "directory exceeds 4096 entries; no partial listing returned",
                ));
            }
            let name = entry.file_name().to_string_lossy().to_string();
            let (kind, size) = match entry.metadata().await {
                Ok(meta) => {
                    let kind = if meta.is_dir() {
                        "directory"
                    } else if meta.is_symlink() {
                        "symlink"
                    } else {
                        "file"
                    };
                    (
                        kind,
                        if meta.is_file() {
                            Some(meta.len())
                        } else {
                            None
                        },
                    )
                }
                Err(_) => ("unknown", None),
            };
            entries.push(json!({
                "name": name,
                "type": kind,
                "size": size,
            }));
        }

        entries.sort_by(|a, b| {
            let a_type = a["type"].as_str().unwrap_or("");
            let b_type = b["type"].as_str().unwrap_or("");
            let a_name = a["name"].as_str().unwrap_or("");
            let b_name = b["name"].as_str().unwrap_or("");
            a_type.cmp(b_type).then(a_name.cmp(b_name))
        });

        Ok(ToolResult::success(
            call.id,
            call.name,
            json!({
                "path": args.path,
                "count": entries.len(),
                "entries": entries,
            }),
        ))
    }
}
