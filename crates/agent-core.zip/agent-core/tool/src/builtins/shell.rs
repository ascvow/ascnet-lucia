//! 执行 shell 命令工具。
//! Shell command execution tool.

use crate::{
    ExecutionPolicy, ExecutionProfile, FileCapability, NoopToolOutputSink, Tool, ToolCall,
    ToolErrorKind, ToolOutputDelta, ToolOutputSink, ToolOutputStream, ToolPermissionScope,
    ToolResult, ToolSpec, WorkspaceGuard,
};
use anyhow::Result;
use async_trait::async_trait;
use serde::Deserialize;
use serde_json::json;
use std::{
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicUsize, Ordering},
        Arc,
    },
    time::Duration,
};
use tokio::io::{AsyncRead, AsyncReadExt};

const DEFAULT_TIMEOUT_MS: u64 = 30_000;
const MAX_TIMEOUT_MS: u64 = 600_000;
/// 单个输出流（stdout / stderr）最大保留字节数。
const MAX_OUTPUT_BYTES: usize = 100 * 1024;

/// 默认注入子进程的环境变量白名单。
///
/// 只保留命令正常运行所需的最小集合。凡是可能携带凭据的变量（`*_API_KEY`、
/// `*_TOKEN`、`AWS_*`、`GITHUB_TOKEN` 等）都不在其中，因此默认不会泄漏到子进程。
const ENV_ALLOWLIST: &[&str] = &[
    "PATH", "HOME", "LANG", "LC_ALL", "LC_CTYPE", "TERM", "TMPDIR", "SHELL", "USER", "LOGNAME",
    "TZ",
];

/// 执行 shell 命令并返回 stdout、stderr 和退出码。
/// Execute a shell command and return stdout, stderr, and exit code.
///
/// 安全约束：工作目录固定在工作区内，环境变量按白名单注入（默认不含任何 Secret），
/// 输出按流截断，超时后终止整个进程树。
pub struct ShellTool {
    /// 全局默认超时（毫秒），通过构造函数配置。
    default_timeout_ms: u64,
    /// 工作区守卫，限定命令的工作目录范围。
    guard: WorkspaceGuard,
    /// 操作系统进程入口复核的可信执行策略。
    execution_policy: ExecutionPolicy,
    /// 当前工具实例正在持有的 Host 管理进程组名额。
    active_processes: AtomicUsize,
}

impl Default for ShellTool {
    fn default() -> Self {
        Self::from_parts(
            DEFAULT_TIMEOUT_MS,
            WorkspaceGuard::default(),
            ExecutionPolicy::serve(),
        )
    }
}

impl ShellTool {
    /// 统一绑定工作区、可信策略和该实例的进程组并发门禁。
    fn from_parts(
        default_timeout_ms: u64,
        guard: WorkspaceGuard,
        execution_policy: ExecutionPolicy,
    ) -> Self {
        Self {
            default_timeout_ms,
            guard,
            execution_policy,
            active_processes: AtomicUsize::new(0),
        }
    }

    /// 使用自定义默认超时创建 ShellTool。
    /// Create a ShellTool with a custom default timeout.
    pub fn with_timeout_ms(timeout_ms: u64) -> Self {
        Self::from_parts(
            timeout_ms.min(MAX_TIMEOUT_MS),
            WorkspaceGuard::default(),
            ExecutionPolicy::serve(),
        )
    }

    /// 以指定工作区守卫创建 ShellTool。
    pub fn new(guard: WorkspaceGuard) -> Self {
        Self::from_parts(DEFAULT_TIMEOUT_MS, guard, ExecutionPolicy::serve())
    }

    /// 以指定工作区守卫和可信执行策略创建 ShellTool。
    ///
    /// `execution_policy` 会在每次调用操作系统前复核；Evaluation 与 Mutation 即使错误地
    /// 开启 `allow_process` 也会返回结构化边界错误，不会启动 Shell。调用方应使用同一
    /// 策略构造 `guard`，确保文件与进程边界一致。
    pub fn with_execution_policy(guard: WorkspaceGuard, execution_policy: ExecutionPolicy) -> Self {
        Self::from_parts(DEFAULT_TIMEOUT_MS, guard, execution_policy)
    }

    /// 解析命令的工作目录。
    ///
    /// 未指定时使用工作区根目录；显式指定时必须落在工作区内，否则拒绝执行。
    /// 不限制目录的守卫返回 `Ok(None)`，表示沿用进程当前目录。
    fn resolve_working_directory(
        &self,
        requested: Option<&str>,
    ) -> Result<Option<PathBuf>, crate::WorkspaceError> {
        match requested {
            Some(raw) => self
                .guard
                .resolve_existing(raw, FileCapability::Read)
                .map(Some),
            None => Ok(self.guard.root().map(Path::to_path_buf)),
        }
    }

    /// 原子预留一个受管进程组名额；达到正数上限时返回该上限。
    fn try_acquire_process_slot(&self) -> Result<Option<ProcessSlotGuard<'_>>, usize> {
        let Some(limit) = self.execution_policy.limits.max_processes else {
            return Ok(None);
        };
        let reserved =
            self.active_processes
                .try_update(Ordering::AcqRel, Ordering::Acquire, |current| {
                    (current < limit).then_some(current + 1)
                });
        match reserved {
            Ok(_) => Ok(Some(ProcessSlotGuard {
                active: &self.active_processes,
            })),
            Err(_) => Err(limit),
        }
    }
}

#[derive(Deserialize)]
struct Args {
    command: String,
    #[serde(default)]
    timeout_ms: Option<u64>,
    #[serde(default)]
    working_directory: Option<String>,
}

/// Shell 进程组的同步回收守卫。
///
/// Agent 超时、用户取消或上层 future 被丢弃时无法再等待异步清理，因此 Unix 平台在
/// `Drop` 中向独立进程组发送 `SIGKILL`，防止后台后代脱离直接子进程后继续运行。
/// 非 Unix 平台仍由 Tokio 的 `kill_on_drop` 回收直接子进程。
struct ProcessGroupGuard {
    #[cfg(unix)]
    process_group: Option<i32>,
}

/// 一次 Shell 调用持有的实例级并发名额；任何返回、错误或取消都会自动释放。
struct ProcessSlotGuard<'a> {
    active: &'a AtomicUsize,
}

impl Drop for ProcessSlotGuard<'_> {
    fn drop(&mut self) {
        self.active.fetch_sub(1, Ordering::AcqRel);
    }
}

impl ProcessGroupGuard {
    /// 使用已经配置为进程组 leader 的直接子进程 PID 创建守卫。
    fn new(child_pid: Option<u32>) -> Self {
        Self {
            #[cfg(unix)]
            process_group: child_pid
                .and_then(|pid| i32::try_from(pid).ok())
                .filter(|pid| *pid > 0),
        }
    }

    /// 主动终止整个进程组，并解除后续重复回收。
    fn terminate(&mut self) {
        #[cfg(unix)]
        if let Some(group) = self.process_group.take() {
            // SAFETY: `group` 来自已成功启动且设置 `process_group(0)` 的直接子进程 PID；
            // 传入负值只向该独立进程组发送信号，不会命中 Host 所在进程组。
            unsafe {
                libc::kill(-group, libc::SIGKILL);
            }
        }
    }
}

impl Drop for ProcessGroupGuard {
    fn drop(&mut self) {
        self.terminate();
    }
}

/// 单个输出流的有限缓冲结果；读取仍会持续到 EOF，避免子进程管道阻塞。
struct CapturedOutput {
    bytes: Vec<u8>,
    truncated: bool,
}

impl CapturedOutput {
    /// 转换为最终结果文本，并保留原有截断提示语义。
    fn into_text(self) -> String {
        let mut text = String::from_utf8_lossy(&self.bytes).into_owned();
        if self.truncated {
            text.push_str("\n... [输出已截断]");
        }
        text
    }
}

/// 持续读取一个子进程输出流，有限保留并同步发布可展示的增量。
async fn capture_stream<R>(
    mut reader: R,
    call_id: String,
    stream: ToolOutputStream,
    output: Arc<dyn ToolOutputSink>,
) -> std::io::Result<CapturedOutput>
where
    R: AsyncRead + Unpin + Send + 'static,
{
    let mut captured = Vec::new();
    let mut truncated = false;
    let mut buffer = [0_u8; 4096];
    loop {
        let read = reader.read(&mut buffer).await?;
        if read == 0 {
            break;
        }
        let remaining = MAX_OUTPUT_BYTES.saturating_sub(captured.len());
        let retained = read.min(remaining);
        if retained > 0 {
            captured.extend_from_slice(&buffer[..retained]);
            output.emit(ToolOutputDelta {
                call_id: call_id.clone(),
                stream,
                delta: String::from_utf8_lossy(&buffer[..retained]).into_owned(),
            });
        }
        if retained < read && !truncated {
            truncated = true;
            output.emit(ToolOutputDelta {
                call_id: call_id.clone(),
                stream,
                delta: "\n... [输出已截断]".into(),
            });
        }
    }
    Ok(CapturedOutput {
        bytes: captured,
        truncated,
    })
}

#[async_trait]
impl Tool for ShellTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec::new(
            "shell",
            "Run a shell command through sh -c and return stdout, stderr, and the exit code. Use this for builds, tests, version-control operations, or tasks without a dedicated tool. Prefer the dedicated tools for reading, writing, listing, and searching files. Each output stream is limited to 100 KiB.",
            json!({
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Complete command passed to sh -c; the command may cause system side effects"
                    },
                    "timeout_ms": {
                        "type": "integer",
                        "description": "Command timeout in milliseconds; default 30000, maximum 600000",
                        "minimum": 1,
                        "maximum": 600000
                    },
                    "working_directory": {
                        "type": "string",
                        "description": "Working directory for the command; defaults to the current process directory"
                    }
                },
                "required": ["command"],
                "additionalProperties": false
            }),
        )
        .with_permission_scope(ToolPermissionScope::Shell)
    }

    async fn call(&self, call: ToolCall) -> Result<ToolResult> {
        self.call_with_output(call, Arc::new(NoopToolOutputSink))
            .await
    }

    /// 启动 Shell 并在等待退出期间持续转发 stdout 与 stderr。
    async fn call_with_output(
        &self,
        call: ToolCall,
        output: Arc<dyn ToolOutputSink>,
    ) -> Result<ToolResult> {
        if self.execution_policy.profile() != ExecutionProfile::Serve
            || !self.execution_policy.allow_process
        {
            return Ok(ToolResult::error_with_kind(
                call.id,
                call.name,
                ToolErrorKind::ProcessBoundaryViolation,
                "当前执行策略禁止 Shell 与子进程执行",
            ));
        }
        if self.execution_policy.limits.max_processes == Some(0) {
            return Ok(ToolResult::error_with_kind(
                call.id,
                call.name,
                ToolErrorKind::ProcessBoundaryViolation,
                "当前执行策略的进程数上限为 0",
            ));
        }
        debug_assert!(self.execution_policy.permits_process_execution());
        let _process_slot = match self.try_acquire_process_slot() {
            Ok(slot) => slot,
            Err(limit) => {
                return Ok(ToolResult::error_with_kind(
                    call.id,
                    call.name,
                    ToolErrorKind::ProcessBoundaryViolation,
                    format!("当前执行策略允许同时运行的 Shell 进程组上限为 {limit}"),
                ));
            }
        };

        let args: Args = call.args_as()?;
        let timeout_ms = args
            .timeout_ms
            .unwrap_or(self.default_timeout_ms)
            .min(MAX_TIMEOUT_MS);

        let working_directory =
            match self.resolve_working_directory(args.working_directory.as_deref()) {
                Ok(dir) => dir,
                Err(error) => {
                    return Ok(ToolResult::error_with_kind(
                        call.id,
                        call.name,
                        error.tool_error_kind(),
                        error.to_string(),
                    ))
                }
            };

        let mut cmd = tokio::process::Command::new("sh");
        cmd.arg("-c").arg(&args.command);

        if let Some(ref dir) = working_directory {
            cmd.current_dir(dir);
        }

        // 清空继承环境后按白名单重新注入，确保 Secret 不会默认进入子进程。
        cmd.env_clear();
        for key in ENV_ALLOWLIST {
            if let Ok(value) = std::env::var(key) {
                cmd.env(key, value);
            }
        }

        cmd.stdout(std::process::Stdio::piped());
        cmd.stderr(std::process::Stdio::piped());
        cmd.kill_on_drop(true);
        // 让 sh 成为独立进程组 leader，超时后可以按组回收其全部后代。
        #[cfg(unix)]
        cmd.process_group(0);

        let mut child = match cmd.spawn() {
            Ok(child) => child,
            Err(error) => {
                return Ok(ToolResult::error(
                    call.id,
                    call.name,
                    format!("命令执行失败: {error}"),
                ));
            }
        };
        let mut process_group_guard = ProcessGroupGuard::new(child.id());
        let stdout = child.stdout.take().expect("Shell stdout 已配置为管道");
        let stderr = child.stderr.take().expect("Shell stderr 已配置为管道");
        let stdout_task = tokio::spawn(capture_stream(
            stdout,
            call.id.clone(),
            ToolOutputStream::Stdout,
            Arc::clone(&output),
        ));
        let stderr_task = tokio::spawn(capture_stream(
            stderr,
            call.id.clone(),
            ToolOutputStream::Stderr,
            output,
        ));
        let status = tokio::time::timeout(Duration::from_millis(timeout_ms), child.wait()).await;

        match status {
            Ok(Ok(status)) => {
                // 直接 `sh` 可以在成功退出前留下后台后代；仍需按组回收，避免绕过并发名额。
                process_group_guard.terminate();
                let stdout = stdout_task.await??.into_text();
                let stderr = stderr_task.await??.into_text();
                let exit_code = status.code().unwrap_or(-1);
                let is_error = !status.success();

                let payload = json!({
                    "stdout": stdout,
                    "stderr": stderr,
                    "exit_code": exit_code,
                });

                if is_error {
                    Ok(ToolResult {
                        call_id: call.id,
                        name: call.name,
                        content: payload,
                        is_error: true,
                        error_kind: Some(ToolErrorKind::Execution),
                        details: None,
                    })
                } else {
                    Ok(ToolResult::success(call.id, call.name, payload))
                }
            }
            Ok(Err(error)) => {
                process_group_guard.terminate();
                let _ = child.kill().await;
                let _ = child.wait().await;
                let _ = stdout_task.await;
                let _ = stderr_task.await;
                Ok(ToolResult::error(
                    call.id,
                    call.name,
                    format!("命令执行失败: {error}"),
                ))
            }
            Err(_) => {
                // 只 kill 直接子进程会留下后代继续运行，因此先按进程组整体回收。
                process_group_guard.terminate();
                let _ = child.kill().await;
                let _ = child.wait().await;
                let _ = stdout_task.await;
                let _ = stderr_task.await;
                Ok(ToolResult::error(
                    call.id,
                    call.name,
                    format!("命令超时（{timeout_ms}ms）"),
                ))
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    /// 记录测试期间收到的增量，验证输出在命令结束前即可观察。
    #[derive(Default)]
    struct CapturingOutputSink {
        outputs: Mutex<Vec<ToolOutputDelta>>,
    }

    impl ToolOutputSink for CapturingOutputSink {
        fn emit(&self, output: ToolOutputDelta) {
            self.outputs.lock().expect("输出锁不应中毒").push(output);
        }
    }

    /// Shell 应在仍处于运行状态时发布 stdout，并在结束后保留完整结果。
    #[test]
    fn shell_streams_output_before_completion() {
        tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .expect("应创建测试运行时")
            .block_on(async {
                let sink = Arc::new(CapturingOutputSink::default());
                let task_sink: Arc<dyn ToolOutputSink> = sink.clone();
                let task = tokio::spawn(async move {
                    ShellTool::default()
                        .call_with_output(
                            ToolCall::new(
                                "shell-live",
                                "shell",
                                json!({"command": "printf first; sleep 0.2; printf second"}),
                            ),
                            task_sink,
                        )
                        .await
                });

                tokio::time::timeout(Duration::from_secs(1), async {
                    loop {
                        if !sink.outputs.lock().expect("输出锁不应中毒").is_empty() {
                            break;
                        }
                        tokio::time::sleep(Duration::from_millis(5)).await;
                    }
                })
                .await
                .expect("首段输出应及时到达");
                assert!(!task.is_finished(), "命令此时应仍在等待第二段输出");
                assert_eq!(
                    sink.outputs.lock().expect("输出锁不应中毒")[0].delta,
                    "first"
                );

                let result = task.await.expect("Shell 任务不应崩溃").expect("调用应成功");
                assert_eq!(result.content["stdout"], "firstsecond");
                assert_eq!(result.content["exit_code"], 0);
            });
    }

    /// 正数 `max_processes` 必须限制同一 Shell 工具实例的并发受管进程组，并在释放后恢复名额。
    #[test]
    fn shell_positive_process_limit_is_enforced() {
        let mut policy = ExecutionPolicy::serve();
        policy.limits.max_processes = Some(1);
        let tool = ShellTool::with_execution_policy(WorkspaceGuard::default(), policy);

        let first = tool
            .try_acquire_process_slot()
            .expect("首个进程组应获得名额")
            .expect("有限策略应返回名额守卫");
        assert!(matches!(tool.try_acquire_process_slot(), Err(1)));

        drop(first);
        assert!(tool
            .try_acquire_process_slot()
            .expect("释放后应可重新获得名额")
            .is_some());
    }

    /// 直接 Shell 正常退出后仍必须回收同组后台后代，不能释放名额后留下游离进程。
    #[cfg(unix)]
    #[test]
    fn shell_success_kills_background_descendants() {
        tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .expect("应创建测试运行时")
            .block_on(async {
                let result = ShellTool::default()
                    .call(ToolCall::new(
                        "shell-background",
                        "shell",
                        json!({
                            "command": "sleep 30 >/dev/null 2>&1 & printf '%s\\n' \"$!\""
                        }),
                    ))
                    .await
                    .expect("Shell 调用应完成");
                let descendant = result.content["stdout"]
                    .as_str()
                    .expect("stdout 应为文本")
                    .trim()
                    .parse::<i32>()
                    .expect("后台后代 PID 应为整数");

                tokio::time::timeout(Duration::from_secs(2), async {
                    loop {
                        // SAFETY: 测试只探测刚才由 Shell 命令报告的后台后代，不发送信号。
                        let probe = unsafe { libc::kill(descendant, 0) };
                        if probe == -1
                            && std::io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH)
                        {
                            break;
                        }
                        tokio::time::sleep(Duration::from_millis(5)).await;
                    }
                })
                .await
                .expect("Shell 正常返回后后台后代必须被回收");
            });
    }

    /// 上层取消 Shell future 时必须回收独立进程组，不能只终止直接 `sh` 子进程。
    #[cfg(unix)]
    #[test]
    fn shell_cancellation_kills_process_group() {
        tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .expect("应创建测试运行时")
            .block_on(async {
                let sink = Arc::new(CapturingOutputSink::default());
                let task_sink: Arc<dyn ToolOutputSink> = sink.clone();
                let task = tokio::spawn(async move {
                    ShellTool::default()
                        .call_with_output(
                            ToolCall::new(
                                "shell-cancel",
                                "shell",
                                json!({
                                    "command": "printf '%s\\n' \"$$\"; sleep 30 & wait"
                                }),
                            ),
                            task_sink,
                        )
                        .await
                });

                let process_group = tokio::time::timeout(Duration::from_secs(2), async {
                    loop {
                        let stdout = sink
                            .outputs
                            .lock()
                            .expect("输出锁不应中毒")
                            .iter()
                            .filter(|delta| delta.stream == ToolOutputStream::Stdout)
                            .map(|delta| delta.delta.as_str())
                            .collect::<String>();
                        if let Some(pid) = stdout
                            .lines()
                            .next()
                            .and_then(|line| line.trim().parse::<i32>().ok())
                        {
                            break pid;
                        }
                        tokio::time::sleep(Duration::from_millis(5)).await;
                    }
                })
                .await
                .expect("Shell 应及时报告自己的进程组 ID");

                task.abort();
                assert!(
                    task.await.expect_err("Shell 任务应被取消").is_cancelled(),
                    "任务必须以取消状态结束"
                );

                tokio::time::timeout(Duration::from_secs(2), async {
                    loop {
                        // SAFETY: 测试只探测刚才由 ShellTool 创建的独立进程组，不发送信号。
                        let result = unsafe { libc::kill(-process_group, 0) };
                        if result == -1
                            && std::io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH)
                        {
                            break;
                        }
                        tokio::time::sleep(Duration::from_millis(5)).await;
                    }
                })
                .await
                .expect("取消后整个 Shell 进程组都应被回收");
            });
    }
}
