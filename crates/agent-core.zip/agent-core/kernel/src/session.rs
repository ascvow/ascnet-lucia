//! Session state for the ReAct loop.
//! ReAct loop 的会话状态。

use crate::model::{ContentBlock, MessageRole, ModelMessage};
use agent_tool::ToolResult;
use serde::{Deserialize, Serialize};

/// Provider-neutral conversation transcript.
/// 与服务商无关的会话记录。
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
pub struct Session {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    system: Option<String>,
    #[serde(default)]
    messages: Vec<ModelMessage>,
}

impl Session {
    /// Create an empty session.
    /// 创建空会话。
    pub fn new() -> Self {
        Self::default()
    }

    /// 从系统提示词和完整消息列表恢复会话。
    ///
    /// 该方法不校验消息顺序，持久化层和原生上下文加载器可以据此恢复经过转换的会话。
    pub fn from_parts(system: Option<String>, messages: Vec<ModelMessage>) -> Self {
        Self { system, messages }
    }

    /// 将会话拆分为系统提示词和完整消息列表。
    ///
    /// 返回值保留消息顺序，可用于持久化或交给外部上下文管理器处理。
    pub fn into_parts(self) -> (Option<String>, Vec<ModelMessage>) {
        (self.system, self.messages)
    }

    /// Set the top-level system prompt.
    /// 设置顶层 system prompt。
    pub fn set_system(&mut self, system: impl Into<String>) {
        self.system = Some(system.into());
    }

    /// Get the system prompt.
    /// 获取 system prompt。
    pub fn system(&self) -> Option<&String> {
        self.system.as_ref()
    }

    /// Push a user message.
    /// 追加用户消息。
    pub fn push_user(&mut self, text: impl Into<String>) {
        self.messages
            .push(ModelMessage::text(MessageRole::User, text.into()));
    }

    /// Push user content blocks, including image or file attachments.
    /// 追加用户内容块，包括图片或文件附件；`content` 为空时不追加消息。
    pub fn push_user_blocks(&mut self, content: Vec<ContentBlock>) {
        if !content.is_empty() {
            self.messages.push(ModelMessage {
                role: MessageRole::User,
                content,
            });
        }
    }

    /// Push an assistant text message.
    /// 追加 assistant 文本消息。
    pub fn push_assistant_text(&mut self, text: impl Into<String>) {
        self.messages
            .push(ModelMessage::text(MessageRole::Assistant, text.into()));
    }

    /// Push assistant content blocks, including tool calls.
    /// 追加 assistant 内容块，包括工具调用。
    pub fn push_assistant_blocks(&mut self, content: Vec<ContentBlock>) {
        if !content.is_empty() {
            self.messages.push(ModelMessage {
                role: MessageRole::Assistant,
                content,
            });
        }
    }

    /// Push a single tool result message.
    /// 追加单个工具结果消息。
    pub fn push_tool_result(&mut self, result: ToolResult) {
        self.push_tool_results(vec![result]);
    }

    /// Push one tool message containing all results from a model turn.
    /// 追加一个工具消息，包含本轮模型请求产生的所有工具结果。
    pub fn push_tool_results(&mut self, results: Vec<ToolResult>) {
        if !results.is_empty() {
            self.messages.push(ModelMessage::tool_results(results));
        }
    }

    /// Read all model messages.
    /// 读取所有模型消息。
    pub fn messages(&self) -> &[ModelMessage] {
        &self.messages
    }

    /// Clone messages for a model request.
    /// 为模型请求克隆消息。
    pub fn model_messages(&self) -> Vec<ModelMessage> {
        self.messages.clone()
    }

    /// Return the last assistant text.
    /// 返回最后一次 assistant 文本。
    pub fn last_assistant_text(&self) -> String {
        self.messages
            .iter()
            .rev()
            .find(|message| matches!(&message.role, MessageRole::Assistant))
            .map(ModelMessage::text_content)
            .unwrap_or_default()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 本次变更前公开给外部 crate 的推理内容块结构。
    #[cfg(feature = "anthropic")]
    #[derive(serde::Deserialize)]
    #[serde(tag = "type", rename_all = "snake_case")]
    enum LegacyReasoningBlock {
        /// 旧版只认识展示文本与不透明签名两个字段。
        Thinking {
            /// 旧版可见推理文本。
            thinking: String,
            /// 旧版不透明服务商签名。
            signature: Option<String>,
        },
    }

    #[test]
    fn parts_round_trip_preserves_session() {
        let mut session = Session::new();
        session.set_system("保持简洁");
        session.push_user("你好");
        session.push_assistant_text("你好");

        let (system, messages) = session.clone().into_parts();

        assert_eq!(Session::from_parts(system, messages), session);
    }

    #[test]
    fn serde_round_trip_preserves_session() {
        let mut session = Session::new();
        session.set_system("使用工具前先检查参数");
        session.push_user("读取配置");
        session.push_assistant_text("配置已读取");

        let encoded = serde_json::to_string(&session).expect("会话应该可以序列化");
        let decoded: Session = serde_json::from_str(&encoded).expect("会话应该可以反序列化");

        assert_eq!(decoded, session);
    }

    /// 旧会话保存未绑定来源的原始签名时仍可读取，但该推理必须按不可回传处理。
    #[test]
    fn legacy_signed_thinking_without_source_route_is_fail_closed() {
        let session: Session = serde_json::from_str(
            r#"{
                "messages": [{
                    "role": "assistant",
                    "content": [{
                        "type": "thinking",
                        "thinking": "旧私有推理",
                        "signature": "sig-legacy"
                    }]
                }]
            }"#,
        )
        .expect("旧会话应保持可读取");

        let transformed = crate::model::transform::transform_messages_for_route(
            session.messages(),
            "anthropic-main",
            "claude-test",
        );

        assert!(transformed.is_empty());
    }

    /// Anthropic 私有推理块及完整来源 scope 必须通过既有签名字段随会话 JSON 无损往返。
    #[cfg(feature = "anthropic")]
    #[test]
    fn serde_round_trip_preserves_provider_private_reasoning_route() {
        let route = crate::model::types::ModelRoute::scoped(
            "anthropic-main",
            "claude-test",
            "endpoint-fingerprint",
        );
        let mut session = Session::new();
        session.push_assistant_blocks(vec![
            ContentBlock::private_signed_thinking("", "sig-private", route.clone()),
            ContentBlock::private_redacted_thinking("encrypted-private", route),
        ]);

        let encoded = serde_json::to_string(&session).expect("私有推理会话应可序列化");
        let decoded: Session = serde_json::from_str(&encoded).expect("私有推理会话应可反序列化");
        let legacy_blocks: Vec<LegacyReasoningBlock> = serde_json::from_value(
            serde_json::to_value(&session.messages()[0].content)
                .expect("当前内容块应可编码为 JSON"),
        )
        .expect("旧版两字段 Thinking 协议应能读取全部私有推理块");

        assert_eq!(decoded, session);
        assert_eq!(legacy_blocks.len(), 2);
        for block in legacy_blocks {
            match block {
                LegacyReasoningBlock::Thinking {
                    thinking,
                    signature,
                } => {
                    assert!(thinking.is_empty());
                    assert!(signature.is_some());
                }
            }
        }
    }
}
